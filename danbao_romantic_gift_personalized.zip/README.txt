PERSONALISED ROMANTIC GIFT WEBSITE — 丹宝 ❤️

Included:
- index.html — gift-box opening website
- photo.jpg — your uploaded image
- music.mp3 — your uploaded song

PREVIEW:
Open index.html in a browser. Keep all three files in the same folder.

PUBLISH FREE WITH GITHUB PAGES:
1. Sign in/create an account at https://github.com/
2. Create a PUBLIC repository, e.g. danbao-gift.
3. Upload index.html, photo.jpg, and music.mp3 to the repository root.
4. Open Settings → Pages.
5. Under Build and deployment, choose “Deploy from a branch”.
6. Select branch “main” and folder “/(root)”, then Save.
7. Wait a few minutes and open the URL shown by GitHub Pages.
8. Test the link on your phone before sending it.

IMPORTANT:
A public GitHub Pages site and its uploaded files can be accessed by anyone who has the URL and may be discoverable. Only upload content you're comfortable sharing. Regional access to hosting can vary. Browsers may require the recipient to tap the music button; autoplay is not guaranteed.
